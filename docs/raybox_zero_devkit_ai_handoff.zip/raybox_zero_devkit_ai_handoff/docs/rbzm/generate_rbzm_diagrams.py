#!/usr/bin/env python3
"""Regenerate RBZM-1 mechanical and KiCad SVGs from the official pin export.

Usage: python3 generate_rbzm_diagrams.py --kicad-dir ../kicad
Python standard library plus kicad-cli. The board-stack artwork contains no
pin assignments and is retained as a source SVG, not redrawn by this script.
"""
import argparse,json,subprocess,tempfile,shutil
from pathlib import Path
import xml.etree.ElementTree as E

BASE=Path(__file__).resolve().parent
NS='http://www.w3.org/2000/svg'
E.register_namespace('',NS)

def resize(path,width=900):
    root=E.parse(path).getroot()
    box=list(map(float,root.get('viewBox').split()))
    root.set('width',str(width));root.set('height',str(round(width*box[3]/box[2],2)))
    E.ElementTree(root).write(path,encoding='unicode')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kicad-dir',type=Path,required=True)
    a=p.parse_args();k=a.kicad_dir.resolve();output=BASE/'diagrams';output.mkdir(exist_ok=True)
    data=json.loads((k/'RBZM_pinout.json').read_text());pins={p['pin']:p for p in data['pins']}
    root=E.parse(BASE/'diagram_templates/physical-interface.svg').getroot()
    for el in root.iter():
        pin=el.get('data-pin');role=el.get('data-role')
        if not pin:continue
        rec=pins[pin];name=rec['name'];direction=rec['direction']
        if role=='label':
            el.text=name
            el.set('fill','#0000ff' if name=='GND' else '#cc0000' if direction=='Power in' else '#172b43')
            el.attrib.pop('font-weight',None)
            if name=='GND' or direction=='Power in':el.set('font-weight','bold')
        if role=='leader':
            el.attrib.pop('marker-start',None);el.attrib.pop('marker-end',None)
            if direction in ('In','In²','Bidir'):el.set('marker-start','url(#signal-arrow)')
            if direction in ('Out','Bidir'):el.set('marker-end','url(#signal-arrow)')
    E.ElementTree(root).write(output/'physical-interface.svg',encoding='unicode')
    with tempfile.TemporaryDirectory() as t:
        t=Path(t);sym=t/'symbol';fp=t/'footprint'
        subprocess.run(['kicad-cli','sym','export','svg',str(k/'RBZM.kicad_sym'),'-o',str(sym)],check=True)
        subprocess.run(['kicad-cli','fp','export','svg',str(k/'Anton.pretty'),'--fp','RBZM_Raybox_Zero_Module','--layers','F.Cu,F.SilkS,F.CrtYd','-o',str(fp)],check=True)
        for source,target in [(sym/'RBZM_Raybox_Zero_Module_unit1.svg','left.svg'),(sym/'RBZM_Raybox_Zero_Module_unit2.svg','right.svg'),(fp/'RBZM_Raybox_Zero_Module.svg','footprint.svg')]:
            shutil.copy(source,output/target);resize(output/target)
    shutil.copy(k/'RBZM_pinout.json',BASE/'RBZM_pinout.json')
    shutil.copy(k/'RBZM_pinout.csv',BASE/'RBZM_pinout.csv')
    print('Regenerated four assignment-dependent SVGs for '+data['revision'])

if __name__=='__main__':main()
