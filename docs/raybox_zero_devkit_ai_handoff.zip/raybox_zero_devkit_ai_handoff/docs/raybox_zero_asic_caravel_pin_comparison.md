# Raybox Zero dedicated ASIC vs Caravel pin and interface comparison

**Revision:** 2026-11-12  
**Scope:** wafer.space GF180 1x0.5 dedicated Raybox Zero ASIC compared with Raybox Zero design 0 in the GFMPW1 Caravel QFN64 implementation.

## How to read the comparison

- **Same:** the board-visible signal and normal function are effectively the same.
- **Equivalent:** implementation details differ, but the signals achieve the same normal user-facing result and can retain the same external hardware interface.
- **Board-unified:** the ASIC combines functions that Caravel exposes separately, but common board wiring or coordinated Chip Selects can present one unified external interface.
- **Inverted:** the function is equivalent but the active polarity differs.
- **Differing:** the intent is related, but implementation or exposed capability differs enough to require deliberate adaptation.
- **ASIC-only / Caravel-only:** no useful one-to-one package-level equivalent exists.

Power, ground, the Caravel thermal pad, physical no-connects and unused wafer.space pads are excluded. Wafer.space numbers are die-pad numbers; Caravel numbers are physical QFN64 package pins. A programmable Caravel pin can appear in several rows because it can expose different functions at different times.

## Complete functional mapping

| WS pin | Dedicated WS ASIC name | Caravel QFN pin | Caravel RBZ name | Match | Function | Difference where applicable |
|---|---|---|---|---|---|---|
| 1 | `CLK` | 22 | `system_clk` | Equivalent | Main clock input | Both accept the board's Raybox system clock. Caravel passes it through its clock/control infrastructure and requires firmware configuration, but the external hardware interface need not change. |
| 2 | `RESET_N` | 21 | `RESETb` | Equivalent | Primary active-low reset | Both can use the same active-low board reset. Caravel resets its management system first and relies on configured reset propagation to reset Raybox during normal operation. See also the Caravel-only opt_user_reset on QFN pin 36. |
| - | - | 36 | `opt_user_reset / ser_rx / io[5]` | Caravel-only | Optional user-design reset and management UART receive | As opt_user_reset, this is active-high and conditional on Caravel pad ownership and mux configuration. The pin is initially associated with management functionality and is also ser_rx, so it is not an unconditional power-on Raybox reset input. |
| 3 | `CTRL_SPI_SCK` | 3, 61 | `reg_sclk, vec_sclk` | Board-unified | Control-interface SPI clock | The ASIC has one combined SPI interface; different command words select the required operation or internal destination. Caravel exposes separate register and vector SPI slaves, but both clock inputs can share one MCU SCLK wire. The independently controlled Chip Selects, reg_cs_n and vec_cs_n, determine which Caravel interface receives each transaction. |
| 4 | `CTRL_SPI_MOSI` | 4, 62 | `reg_mosi, vec_mosi` | Board-unified | Control-interface SPI data input | The ASIC sends command and payload words over one MOSI input. Caravel's two MOSI inputs can share one MCU MOSI wire. Together with shared SCLK, the MCU needs only two common SPI wires rather than separate SCLK/MOSI pairs for both Caravel slaves. |
| 7 | `CTRL_SPI_CS_N` | 2, 60 | `reg_cs_n, vec_cs_n` | Board-unified | Control-interface Chip Select | The ASIC has one Chip Select for its combined command-driven SPI interface. Caravel instead provides two independently driven Chip Selects: reg_cs_n selects the register slave and vec_cs_n selects the vector slave. The MCU asserts only the required Chip Select while sharing SCLK and MOSI. |
| 8 | `DEBUG` | 5-7 | `debug_vec, debug_map, debug_trace` | Board-unified | Debug-feature control | The ASIC has one debug input. Caravel exposes three debug inputs, but one common board DEBUG line can drive debug_vec, debug_map and debug_trace together to provide equivalent normal user-facing debug control. Separate wiring remains optional when independent control is wanted. |
| 9 | `DEC_X` | 11 | `mode0_inc_px` | Equivalent | Automatic/demo movement on X | Despite the names implying opposite movement directions, they provide the same normal user-facing demo-control behaviour and can use the same external control. |
| 10 | `DEC_Y` | 12 | `mode1_inc_py` | Equivalent | Automatic/demo movement on Y | Despite the names implying opposite movement directions, they provide the same normal user-facing demo-control behaviour and can use the same external control. |
| 11 | `REG` | 8 | `reg_outs_enb` | Inverted | Registered-output selection | The ASIC REG input is active-high; Caravel reg_outs_enb is active-low. |
| 12 | `TEX_PMOD_TYPE` | - | - | ASIC-only | Select texture-PMOD wiring convention | Caravel has no logical PMOD-type selector, but still exposes the same texture signals: CS, SCLK and IO0-IO3. A Caravel board can therefore support the alternative PMOD convention through physical PCB/adapter rewiring instead of logical selection. |
| 18 | `GEN_TEXb` | 13 | `mode2_gen_tex` | Inverted | Generated-texture select when TEX_PMOD_TYPE=1 | GEN_TEXb is this function only in TEX_PMOD_TYPE=1 mode, corresponding to the Digilent QSPI PMOD wiring. In that mode the ASIC input is active-low, while Caravel's mode2_gen_tex is active-high. |
| 13 | `TM1QSPI_CS_N` | 53 | `tex_cs_n` | Same | Texture-memory Chip Select | Different names and physical locations only. |
| 16 | `TM1QSPI_SCK` | 54 | `tex_sclk` | Same | Texture-memory serial clock | Different names and physical locations only. |
| 14 | `TM1QSPI_IO0` | 55 | `tex_io0` | Same | Bidirectional texture-data line | Both implementations use IO0 bidirectionally. |
| 15 | `TM1QSPI_IO1` | 57 | `tex_io1` | Same | Texture-data input | - |
| 21 | `TM1QSPI_IO2` | 58 | `tex_io2` | Same | Texture-data input | - |
| 22 | `TM1QSPI_IO3` | 59 | `tex_io3` | Same | Fourth texture-data line | The physical signal exists on both; the current Caravel Raybox implementation does not meaningfully consume IO3 internally. |
| 23 | `RED[1]` | 45 | `rgb[1] / red bit 1` | Same | VGA red MSB | Caravel's generic rgb numbering obscures the colour name. |
| 29 | `RED[0]` | 44 | `rgb[0] / red bit 0` | Same | VGA red LSB | - |
| 24 | `GREEN[1]` | 48 | `rgb[3] / green bit 1` | Same | VGA green MSB | - |
| 30 | `GREEN[0]` | 46 | `rgb[2] / green bit 0` | Same | VGA green LSB | - |
| 27 | `BLUE[1]` | 51 | `rgb[5] / blue bit 1` | Same | VGA blue MSB | - |
| 31 | `BLUE[0]` | 50 | `rgb[4] / blue bit 0` | Same | VGA blue LSB | - |
| 32 | `HSYNC_N` | 42 | `hsync_n` | Same | VGA horizontal sync | - |
| 28 | `VSYNC_N` | 43 | `vsync_n` | Same | VGA vertical sync | - |
| 33 | `HBLANK` | 14 | `gpout[0], selector 0` | Differing | Horizontal blanking diagnostic | A fixed ASIC output but a programmable Caravel output. QFN pin 14 cannot simultaneously expose its other selectable signals. |
| 34 | `VBLANK` | 15 | `gpout[1], selector 0` | Differing | Vertical blanking diagnostic | A fixed ASIC output but a programmable Caravel output. |
| 37 | `HMAX` | 14 | `gpout[0], selector 1` | Differing | Horizontal terminal-count diagnostic | Shares Caravel pin 14 with HBLANK and the other gpout[0] choices. |
| 38 | `VMAX` | 15 | `gpout[1], selector 1` | Differing | Vertical terminal-count diagnostic | Shares Caravel pin 15 with VBLANK and the other gpout[1] choices. |
| 39 | `VPOS[0]` | 14-16 | `any gpout[*], selector 8` | Differing | Vertical-position bit 0 | A fixed ASIC output, but selectable on any of three programmable Caravel outputs. |
| 40 | `VPOS[1]` | 14-16 | `any gpout[*], selector 9` | Differing | Vertical-position bit 1 | A fixed ASIC output, but selectable on any of three programmable Caravel outputs. |
| 43-48 | `VPOS[2:7]` | - | - | ASIC-only | Vertical-position bits 2-7 | These bits cannot be selected by the current Caravel gpout mux. |
| 49 | `VPOS[8]` | 14-16 | `any gpout[*], selector 10` | Differing | Vertical-position bit 8 | Fixed on the ASIC; programmable on Caravel. |
| 50 | `VPOS[9]` | 14-16 | `any gpout[*], selector 11` | Differing | Vertical-position bit 9 | Fixed on the ASIC; programmable on Caravel. |
| - | - | 14-16 | `other gpout[2:0] selections` | Caravel-only | Additional programmable diagnostics | Additional choices are rbzero_reset (0, gpout[2] only), clk (1, gpout[2] only), vinf (2), clk/4 (3), hpos[0] (4), hpos[1] (5), hpos[8] (6), hpos[9] (7), tex_oeb0 (12), tex_in[0] (13), vec_csb (14) and reg_csb (15). |
| - | - | 31-35 | `jtag/io[0], hk_sdo/io[1], hk_sdi/io[2], hk_csb/io[3], hk_sck/io[4]` | Caravel-only | Management and housekeeping interface | Used for Caravel boot, housekeeping SPI and programming; not part of the dedicated ASIC. |
| - | - | 37 | `ser_tx/io[6]` | Caravel-only | Management UART transmit | No dedicated-ASIC equivalent. |
| - | - | 41 | `irq/io[7]` | Caravel-only | Management interrupt/user IO | No dedicated-ASIC equivalent. |
| - | - | 24 | `flash_csb` | Caravel-only | Management-firmware flash select | Separate from the Raybox texture flash. |
| - | - | 25 | `flash_clk` | Caravel-only | Management-firmware flash clock | Separate from the Raybox texture flash. |
| - | - | 26 | `flash_io0/mosi` | Caravel-only | Management-firmware flash output | Fixed as output/MOSI in this Caravel implementation. |
| - | - | 27 | `flash_io1/miso` | Caravel-only | Management-firmware flash input | Fixed as input/MISO; dual/quad management flash is not implemented. |
| - | - | 28 | `gpio` | Caravel-only | Standalone management GPIO | Can provide a firmware-ready or status indication. |

## Caravel `rgb[5:0]` bit order (`BBGGRR`)

The Caravel Raybox top-level Verilog explicitly describes `o_rgb[5:0]` as `BBGGRR`. The vector is therefore ordered as blue in bits 5:4, green in bits 3:2 and red in bits 1:0:

| Caravel bit | Colour | Colour bit | Equivalent named signal |
|---|---|---|---|
| 0 | Red | 0 (LSB) | rgb[0] = red[0] |
| 1 | Red | 1 (MSB) | rgb[1] = red[1] |
| 2 | Green | 0 (LSB) | rgb[2] = green[0] |
| 3 | Green | 1 (MSB) | rgb[3] = green[1] |
| 4 | Blue | 0 (LSB) | rgb[4] = blue[0] |
| 5 | Blue | 1 (MSB) | rgb[5] = blue[1] |

In particular, **`rgb[4]` is blue bit 0**, while **`rgb[0]` is red bit 0**. The colour order is confirmed by the concatenation of `rbzero_rgb_out[5:4]` (blue), `[3:2]` (green) and `[1:0]` (red) in `top_raybox_zero_fsm.v`. `top_design_mux.v` then maps this six-bit vector to `IO[15:10]` without reversing it.

## Shared board wiring for the Caravel control and debug interfaces

The dedicated ASIC has one combined SPI interface. Its command words identify the requested operation or internal destination. Caravel instead exposes separate register and vector SPI slaves, but an MCU does not need separate clock and MOSI wiring for each slave. Likewise, one common DEBUG line can drive all three Caravel debug inputs when independent debug-feature control is unnecessary:

| MCU net | Caravel destinations | Purpose |
|---|---|---|
| SPI SCLK | QFN 3 `reg_sclk` and QFN 61 `vec_sclk` | One shared clock wire |
| SPI MOSI | QFN 4 `reg_mosi` and QFN 62 `vec_mosi` | One shared data wire |
| Register Chip Select | QFN 2 `reg_cs_n` | Select register SPI slave |
| Vector Chip Select | QFN 60 `vec_cs_n` | Select vector SPI slave |
| DEBUG | QFN 5 `debug_vec`, QFN 6 `debug_map`, QFN 7 `debug_trace` | One common line can enable or disable all three together |

Only one Chip Select should normally be asserted for a transaction. Thus the Caravel control SPI uses four MCU-controlled nets in total: two shared SPI signals and two independent Chip Selects. It does not require parallel transactions on both slaves. A fifth common DEBUG net can fan out to all three debug inputs if independent debug control is unnecessary.

## Texture-PMOD implications

The dedicated ASIC's `TEX_PMOD_TYPE` is a logical selector for its supported connector wiring convention. Caravel lacks that selector, but exposes the same board-level texture signals: `tex_cs_n`, `tex_sclk` and `tex_io[3:0]`. A Caravel adapter can therefore implement the desired PMOD convention by physically routing those signals to the appropriate connector pins. This changes adapter wiring rather than the MCU or texture-memory protocol.

## Reset and startup implications

- The dedicated ASIC's `RESET_N` directly resets Raybox.
- Caravel QFN pin 21 `RESETb` is electrically compatible with the same active-low board reset, but first resets the Caravel management system. Normal Raybox reset behaviour relies on firmware establishing the intended mux/reset-propagation policy.
- QFN pin 36 `opt_user_reset / ser_rx / io[5]` is an additional Caravel-only route. It can become an active-high user-design reset only after the pad and mux are configured appropriately.
- Caravel also requires management firmware, firmware flash, GPIO transfer, mux selection and an explicit design-reset sequence before Raybox should be considered ready.

For a common board, use the active-low reset net for dedicated `RESET_N` or Caravel `RESETb`. Treat `opt_user_reset` as an optional Caravel-specific enhancement, not as the primary power-on reset.

## Caravel `gpout[2:0]` selector reference

| Selector | gpout[0] | gpout[1] | gpout[2] |
|---|---|---|---|
| 0 | hblank | vblank | rbzero_reset |
| 1 | hmax | vmax | clk |
| 2 | vinf | vinf | vinf |
| 3 | clk/4 | clk/4 | clk/4 |
| 4 | hpos[0] | hpos[0] | hpos[0] |
| 5 | hpos[1] | hpos[1] | hpos[1] |
| 6 | hpos[8] | hpos[8] | hpos[8] |
| 7 | hpos[9] | hpos[9] | hpos[9] |
| 8 | vpos[0] | vpos[0] | vpos[0] |
| 9 | vpos[1] | vpos[1] | vpos[1] |
| 10 | vpos[8] | vpos[8] | vpos[8] |
| 11 | vpos[9] | vpos[9] | vpos[9] |
| 12 | tex_oeb0 | tex_oeb0 | tex_oeb0 |
| 13 | tex_in[0] | tex_in[0] | tex_in[0] |
| 14 | vec_csb | vec_csb | vec_csb |
| 15 | reg_csb | reg_csb | reg_csb |

The dedicated ASIC exposes `HBLANK`, `VBLANK`, `HMAX`, `VMAX` and all ten `VPOS` bits simultaneously. Caravel has only three `gpout` pins, although they are more flexible. `VPOS[2:7]` are not selectable by the current Caravel mux. `gpout[2]` is always unregistered; `gpout[0]` and `gpout[1]` follow `reg_outs_enb`.

Selector 12 is especially useful because `tex_oeb0` exposes the direction state of bidirectional `tex_io0`: low means its output driver is enabled; high means input/high-impedance.

## Practical common-devkit interface

A shared baseboard should route by logical function rather than package number:

- system clock and active-low primary reset;
- RGB222, `hsync_n` and `vsync_n`;
- texture CS, SCLK and IO0-IO3;
- shared control-SPI SCLK/MOSI plus variant-specific Chip Select handling;
- generated-texture selection with polarity adaptation;
- registered-output selection with polarity adaptation;
- mode controls through variant-specific adapter logic, with DEBUG either fanned out as one common line or exposed separately on Caravel;
- diagnostics through either fixed ASIC pins or selected Caravel `gpout` sources;
- a Caravel firmware-ready indication before the controller assumes the user design is operational.

The cleanest architecture is a common logical interface with variant-specific ASIC modules or adapters. Caravel-specific management flash, housekeeping SPI, UART and firmware sequencing should remain on the Caravel module rather than complicating the dedicated-ASIC interface.

## Primary sources

- Wafer.space slot definition: <https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/librelane/slots/slot_1x0p5.yaml>
- Dedicated-ASIC pad-ring script: <https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/scripts/padring.py>
- Wafer.space COB/mezzanine schematic: <https://github.com/wafer-space/chip-on-board-wire-bonded-pcbs/blob/main/run-2/1x0p5-cob/mezzanine-1x0p5.kicad_sch>
- Caravel wrapper: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/user_project_wrapper.v>
- Caravel design mux: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/mux/top_design_mux.v>
- Raybox Caravel top: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/raybox-zero-fsm/src/rtl/top_raybox_zero_fsm.v>
- Caravel QFN64 schematic: <https://github.com/efabless/caravel_board/blob/2812cfd3896e2b1004b5f4559e0601c90cd18f55/hardware/breakout/caravel-M.2-card-QFN/caravel-M.2-card-QFN.kicad_sch>
