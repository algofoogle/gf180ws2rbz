# Package scope and omissions

This handoff is a curated context and generated-asset package. It is not a complete source mirror, fabrication release, or verbatim chat export. This document records the meaningful things that are **not** included so that a future AI or engineer does not mistake a link or summary for a locally archived source.

## Required external inputs

- The original hierarchical GDS used by `scripts/generate_padring_diagram.py`.
  - Consequently, fresh extraction of the Metal5 corner artwork, top-level Metal4/core extent, and GDS pad-marker geometry requires obtaining that GDS again.
- The Caravel QFN64 M.2 KiCad schematic required by `scripts/generate_caravel_raybox_diagram.py`.
- The wafer.space `slot_1x0p5.yaml` and upstream `scripts/padring.py`.
- The wafer.space COB/mezzanine KiCad schematic containing die-pad symbol `U102`.

These sources are linked from `raybox_zero_caravel_useful_links.md`; they are not copied into the archive.

## Upstream RTL and firmware

The upstream repositories are not vendored. In particular, the package does not contain local copies of:

- `user_project_wrapper.v`;
- `top_design_mux.v`;
- `user_defines.v`;
- `top_raybox_zero_fsm.v`;
- `trzf_test.c`;
- the wider Caravel or Raybox Zero RTL trees;
- `caravel_hkflash.py`;
- a compiled Caravel management-firmware binary or flash image.

The detailed guide records the relevant behavior and links to important source lines, but those links can change or disappear. A controlled hardware project should pin or vendor permitted copies of the exact revisions.

## Reference-board design files

There are no local copies of the Caravel GF180 5 V development-board schematic, Caravel QFN64 breakout/M.2 design, wafer.space COB/mezzanine PCB files, Gerbers, drill files, assembly outputs, complete BOMs, or placement files.

## Dedicated-ASIC KiCad and machine-readable assets

Only the Caravel KiCad symbol library is included. The archive does not yet contain:

- a standalone KiCad symbol for the wafer.space 72-pad die or standard mezzanine;
- a bare-die/bond-pad footprint;
- COB/mezzanine connector symbols and footprints;
- a dedicated-ASIC carrier/module schematic;
- a separate CSV/JSON pin map or coordinate table.

The dedicated-die mapping and coordinates are encoded in the diagram generator and shown in the diagram, but are not exported as a neutral machine-readable interface definition.

## Devkit implementation not yet created

The archive proposes a multi-ASIC architecture, but contains no completed devkit:

- schematic or PCB layout;
- common module-connector specification;
- Caravel, wafer.space, or future-ASIC adapter/module schematics;
- power tree and worst-case current budget;
- reset/power-sequencing implementation;
- level-translation selection and tolerance analysis;
- BOM, costing, sourcing, or lifecycle analysis;
- mechanical drawings, enclosure, or 3D models;
- signal-integrity or power-integrity analysis;
- fabrication/assembly release files;
- bring-up, validation, production-test, or fixture design.

## Component documentation and qualification

No datasheets or application notes are bundled for TXB0104, MS9288C, CH32X033, APX803S-46SA-7, MCP1319, FTDI parts, SN74LV1T34, SN74LVC1G125, candidate QSPI flashes, regulators, oscillators, connectors, ESD devices, or video-interface parts. The handoff contains engineering summaries and recommendations, not complete component qualification.

## Reproducibility and governance

The package does not include:

- a Git repository or revision history for the handoff itself;
- a source lockfile pinning every external repository and file hash;
- automated diagram/symbol regression tests;
- CI configuration;
- a container, Nix environment, or fully pinned toolchain;
- Inkscape, which remains an external optional dependency for some raster/PDF exports;
- an explicit generated-artifact licence or third-party licence bundle.

## Conversation and intermediate work

The archive does not contain a platform-exported, byte-for-byte transcript of the original chat, because that export is not available to the assistant. It now includes `conversation_reconstruction.md`, which preserves the available request chronology and reconstructed outcomes with its limitations stated explicitly.

It also omits most intermediate diagram revisions, discarded layout experiments, scratch net-tracing output, temporary analysis scripts, and original uploaded files other than assets deliberately included elsewhere in the package.

## Highest-value future additions

1. Original hierarchical GDS, if redistribution is permitted.
2. Pinned snapshots or submodules for the relevant RTL, firmware, and KiCad sources.
3. A neutral CSV/JSON cross-implementation pin map.
4. A formal baseboard-to-module connector and electrical-interface specification.
5. Actual devkit schematic, power/reset design, BOM, and validation plan.
6. A source-revision and file-hash lockfile.
