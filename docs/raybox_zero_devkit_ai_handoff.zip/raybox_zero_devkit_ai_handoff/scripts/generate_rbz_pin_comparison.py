#!/usr/bin/env python3
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate, Frame, KeepTogether, PageTemplate, Paragraph,
    PageBreak, Spacer, Table, TableStyle,
)


OUT = Path("output")
MD = OUT / "raybox_zero_asic_caravel_pin_comparison.md"
PDF = OUT / "raybox_zero_asic_caravel_pin_comparison_landscape.pdf"
OUT.mkdir(parents=True, exist_ok=True)

rows = [
    ("1", "CLK", "22", "system_clk", "Equivalent", "Main clock input", "Both accept the board's Raybox system clock. Caravel passes it through its clock/control infrastructure and requires firmware configuration, but the external hardware interface need not change."),
    ("2", "RESET_N", "21", "RESETb", "Equivalent", "Primary active-low reset", "Both can use the same active-low board reset. Caravel resets its management system first and relies on configured reset propagation to reset Raybox during normal operation. See also the Caravel-only opt_user_reset on QFN pin 36."),
    ("-", "-", "36", "opt_user_reset / ser_rx / io[5]", "Caravel-only", "Optional user-design reset and management UART receive", "As opt_user_reset, this is active-high and conditional on Caravel pad ownership and mux configuration. The pin is initially associated with management functionality and is also ser_rx, so it is not an unconditional power-on Raybox reset input."),
    ("3", "CTRL_SPI_SCK", "3, 61", "reg_sclk, vec_sclk", "Board-unified", "Control-interface SPI clock", "The ASIC has one combined SPI interface; different command words select the required operation or internal destination. Caravel exposes separate register and vector SPI slaves, but both clock inputs can share one MCU SCLK wire. The independently controlled Chip Selects, reg_cs_n and vec_cs_n, determine which Caravel interface receives each transaction."),
    ("4", "CTRL_SPI_MOSI", "4, 62", "reg_mosi, vec_mosi", "Board-unified", "Control-interface SPI data input", "The ASIC sends command and payload words over one MOSI input. Caravel's two MOSI inputs can share one MCU MOSI wire. Together with shared SCLK, the MCU needs only two common SPI wires rather than separate SCLK/MOSI pairs for both Caravel slaves."),
    ("7", "CTRL_SPI_CS_N", "2, 60", "reg_cs_n, vec_cs_n", "Board-unified", "Control-interface Chip Select", "The ASIC has one Chip Select for its combined command-driven SPI interface. Caravel instead provides two independently driven Chip Selects: reg_cs_n selects the register slave and vec_cs_n selects the vector slave. The MCU asserts only the required Chip Select while sharing SCLK and MOSI."),
    ("8", "DEBUG", "5-7", "debug_vec, debug_map, debug_trace", "Board-unified", "Debug-feature control", "The ASIC has one debug input. Caravel exposes three debug inputs, but one common board DEBUG line can drive debug_vec, debug_map and debug_trace together to provide equivalent normal user-facing debug control. Separate wiring remains optional when independent control is wanted."),
    ("9", "DEC_X", "11", "mode0_inc_px", "Equivalent", "Automatic/demo movement on X", "Despite the names implying opposite movement directions, they provide the same normal user-facing demo-control behaviour and can use the same external control."),
    ("10", "DEC_Y", "12", "mode1_inc_py", "Equivalent", "Automatic/demo movement on Y", "Despite the names implying opposite movement directions, they provide the same normal user-facing demo-control behaviour and can use the same external control."),
    ("11", "REG", "8", "reg_outs_enb", "Inverted", "Registered-output selection", "The ASIC REG input is active-high; Caravel reg_outs_enb is active-low."),
    ("12", "TEX_PMOD_TYPE", "-", "-", "ASIC-only", "Select texture-PMOD wiring convention", "Caravel has no logical PMOD-type selector, but still exposes the same texture signals: CS, SCLK and IO0-IO3. A Caravel board can therefore support the alternative PMOD convention through physical PCB/adapter rewiring instead of logical selection."),
    ("18", "GEN_TEXb", "13", "mode2_gen_tex", "Inverted", "Generated-texture select when TEX_PMOD_TYPE=1", "GEN_TEXb is this function only in TEX_PMOD_TYPE=1 mode, corresponding to the Digilent QSPI PMOD wiring. In that mode the ASIC input is active-low, while Caravel's mode2_gen_tex is active-high."),
    ("13", "TM1QSPI_CS_N", "53", "tex_cs_n", "Same", "Texture-memory Chip Select", "Different names and physical locations only."),
    ("16", "TM1QSPI_SCK", "54", "tex_sclk", "Same", "Texture-memory serial clock", "Different names and physical locations only."),
    ("14", "TM1QSPI_IO0", "55", "tex_io0", "Same", "Bidirectional texture-data line", "Both implementations use IO0 bidirectionally."),
    ("15", "TM1QSPI_IO1", "57", "tex_io1", "Same", "Texture-data input", "-"),
    ("21", "TM1QSPI_IO2", "58", "tex_io2", "Same", "Texture-data input", "-"),
    ("22", "TM1QSPI_IO3", "59", "tex_io3", "Same", "Fourth texture-data line", "The physical signal exists on both; the current Caravel Raybox implementation does not meaningfully consume IO3 internally."),
    ("23", "RED[1]", "45", "rgb[1] / red bit 1", "Same", "VGA red MSB", "Caravel's generic rgb numbering obscures the colour name."),
    ("29", "RED[0]", "44", "rgb[0] / red bit 0", "Same", "VGA red LSB", "-"),
    ("24", "GREEN[1]", "48", "rgb[3] / green bit 1", "Same", "VGA green MSB", "-"),
    ("30", "GREEN[0]", "46", "rgb[2] / green bit 0", "Same", "VGA green LSB", "-"),
    ("27", "BLUE[1]", "51", "rgb[5] / blue bit 1", "Same", "VGA blue MSB", "-"),
    ("31", "BLUE[0]", "50", "rgb[4] / blue bit 0", "Same", "VGA blue LSB", "-"),
    ("32", "HSYNC_N", "42", "hsync_n", "Same", "VGA horizontal sync", "-"),
    ("28", "VSYNC_N", "43", "vsync_n", "Same", "VGA vertical sync", "-"),
    ("33", "HBLANK", "14", "gpout[0], selector 0", "Differing", "Horizontal blanking diagnostic", "A fixed ASIC output but a programmable Caravel output. QFN pin 14 cannot simultaneously expose its other selectable signals."),
    ("34", "VBLANK", "15", "gpout[1], selector 0", "Differing", "Vertical blanking diagnostic", "A fixed ASIC output but a programmable Caravel output."),
    ("37", "HMAX", "14", "gpout[0], selector 1", "Differing", "Horizontal terminal-count diagnostic", "Shares Caravel pin 14 with HBLANK and the other gpout[0] choices."),
    ("38", "VMAX", "15", "gpout[1], selector 1", "Differing", "Vertical terminal-count diagnostic", "Shares Caravel pin 15 with VBLANK and the other gpout[1] choices."),
    ("39", "VPOS[0]", "14-16", "any gpout[*], selector 8", "Differing", "Vertical-position bit 0", "A fixed ASIC output, but selectable on any of three programmable Caravel outputs."),
    ("40", "VPOS[1]", "14-16", "any gpout[*], selector 9", "Differing", "Vertical-position bit 1", "A fixed ASIC output, but selectable on any of three programmable Caravel outputs."),
    ("43-48", "VPOS[2:7]", "-", "-", "ASIC-only", "Vertical-position bits 2-7", "These bits cannot be selected by the current Caravel gpout mux."),
    ("49", "VPOS[8]", "14-16", "any gpout[*], selector 10", "Differing", "Vertical-position bit 8", "Fixed on the ASIC; programmable on Caravel."),
    ("50", "VPOS[9]", "14-16", "any gpout[*], selector 11", "Differing", "Vertical-position bit 9", "Fixed on the ASIC; programmable on Caravel."),
    ("-", "-", "14-16", "other gpout[2:0] selections", "Caravel-only", "Additional programmable diagnostics", "Additional choices are rbzero_reset (0, gpout[2] only), clk (1, gpout[2] only), vinf (2), clk/4 (3), hpos[0] (4), hpos[1] (5), hpos[8] (6), hpos[9] (7), tex_oeb0 (12), tex_in[0] (13), vec_csb (14) and reg_csb (15)."),
    ("-", "-", "31-35", "jtag/io[0], hk_sdo/io[1], hk_sdi/io[2], hk_csb/io[3], hk_sck/io[4]", "Caravel-only", "Management and housekeeping interface", "Used for Caravel boot, housekeeping SPI and programming; not part of the dedicated ASIC."),
    ("-", "-", "37", "ser_tx/io[6]", "Caravel-only", "Management UART transmit", "No dedicated-ASIC equivalent."),
    ("-", "-", "41", "irq/io[7]", "Caravel-only", "Management interrupt/user IO", "No dedicated-ASIC equivalent."),
    ("-", "-", "24", "flash_csb", "Caravel-only", "Management-firmware flash select", "Separate from the Raybox texture flash."),
    ("-", "-", "25", "flash_clk", "Caravel-only", "Management-firmware flash clock", "Separate from the Raybox texture flash."),
    ("-", "-", "26", "flash_io0/mosi", "Caravel-only", "Management-firmware flash output", "Fixed as output/MOSI in this Caravel implementation."),
    ("-", "-", "27", "flash_io1/miso", "Caravel-only", "Management-firmware flash input", "Fixed as input/MISO; dual/quad management flash is not implemented."),
    ("-", "-", "28", "gpio", "Caravel-only", "Standalone management GPIO", "Can provide a firmware-ready or status indication."),
]

gpout = [
    ("0", "hblank", "vblank", "rbzero_reset"),
    ("1", "hmax", "vmax", "clk"),
    ("2", "vinf", "vinf", "vinf"),
    ("3", "clk/4", "clk/4", "clk/4"),
    ("4", "hpos[0]", "hpos[0]", "hpos[0]"),
    ("5", "hpos[1]", "hpos[1]", "hpos[1]"),
    ("6", "hpos[8]", "hpos[8]", "hpos[8]"),
    ("7", "hpos[9]", "hpos[9]", "hpos[9]"),
    ("8", "vpos[0]", "vpos[0]", "vpos[0]"),
    ("9", "vpos[1]", "vpos[1]", "vpos[1]"),
    ("10", "vpos[8]", "vpos[8]", "vpos[8]"),
    ("11", "vpos[9]", "vpos[9]", "vpos[9]"),
    ("12", "tex_oeb0", "tex_oeb0", "tex_oeb0"),
    ("13", "tex_in[0]", "tex_in[0]", "tex_in[0]"),
    ("14", "vec_csb", "vec_csb", "vec_csb"),
    ("15", "reg_csb", "reg_csb", "reg_csb"),
]

rgb_order = [
    ("0", "Red", "0 (LSB)", "rgb[0] = red[0]"),
    ("1", "Red", "1 (MSB)", "rgb[1] = red[1]"),
    ("2", "Green", "0 (LSB)", "rgb[2] = green[0]"),
    ("3", "Green", "1 (MSB)", "rgb[3] = green[1]"),
    ("4", "Blue", "0 (LSB)", "rgb[4] = blue[0]"),
    ("5", "Blue", "1 (MSB)", "rgb[5] = blue[1]"),
]


def code(s):
    return f"`{s}`" if s != "-" else "-"


def md_table(headers, body):
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for row in body:
        out.append("| " + " | ".join(str(x).replace("|", "\\|") for x in row) + " |")
    return "\n".join(out)


md_rows = []
for a_pin, a_name, c_pin, c_name, match, function, difference in rows:
    md_rows.append((a_pin, code(a_name), c_pin, code(c_name), match, function, difference))

md = f"""# Raybox Zero dedicated ASIC vs Caravel pin and interface comparison

**Revision:** 2026-11-12  
**Scope:** wafer.space GF180 1x0.5 dedicated Raybox Zero ASIC compared with Raybox Zero design 0 in the GFMPW1 Caravel QFN64 implementation.

## How to read the comparison

- **Same:** the board-visible signal and normal function are effectively the same.
- **Equivalent:** implementation details differ, but the signals achieve the same normal user-facing result and can retain the same external hardware interface.
- **Board-unified:** the ASIC combines functions that Caravel exposes separately, but common board wiring or coordinated Chip Selects can present one unified external interface.
- **Inverted:** the function is equivalent but the active polarity differs.
- **Differing:** the intent is related, but implementation or exposed capability differs enough to require deliberate adaptation.
- **ASIC-only / Caravel-only:** no useful one-to-one package-level equivalent exists.

Power, ground, the Caravel thermal pad, physical no-connects and unused wafer.space pads are excluded. Wafer.space numbers are die-pad numbers; Caravel numbers are physical QFN64 package pins. A programmable Caravel pin can appear in several rows because it can expose different functions at different times.

## Complete functional mapping

{md_table(["WS pin", "Dedicated WS ASIC name", "Caravel QFN pin", "Caravel RBZ name", "Match", "Function", "Difference where applicable"], md_rows)}

## Caravel `rgb[5:0]` bit order (`BBGGRR`)

The Caravel Raybox top-level Verilog explicitly describes `o_rgb[5:0]` as `BBGGRR`. The vector is therefore ordered as blue in bits 5:4, green in bits 3:2 and red in bits 1:0:

{md_table(["Caravel bit", "Colour", "Colour bit", "Equivalent named signal"], rgb_order)}

In particular, **`rgb[4]` is blue bit 0**, while **`rgb[0]` is red bit 0**. The colour order is confirmed by the concatenation of `rbzero_rgb_out[5:4]` (blue), `[3:2]` (green) and `[1:0]` (red) in `top_raybox_zero_fsm.v`. `top_design_mux.v` then maps this six-bit vector to `IO[15:10]` without reversing it.

## Shared board wiring for the Caravel control and debug interfaces

The dedicated ASIC has one combined SPI interface. Its command words identify the requested operation or internal destination. Caravel instead exposes separate register and vector SPI slaves, but an MCU does not need separate clock and MOSI wiring for each slave. Likewise, one common DEBUG line can drive all three Caravel debug inputs when independent debug-feature control is unnecessary:

{md_table(["MCU net", "Caravel destinations", "Purpose"], [
    ("SPI SCLK", "QFN 3 `reg_sclk` and QFN 61 `vec_sclk`", "One shared clock wire"),
    ("SPI MOSI", "QFN 4 `reg_mosi` and QFN 62 `vec_mosi`", "One shared data wire"),
    ("Register Chip Select", "QFN 2 `reg_cs_n`", "Select register SPI slave"),
    ("Vector Chip Select", "QFN 60 `vec_cs_n`", "Select vector SPI slave"),
    ("DEBUG", "QFN 5 `debug_vec`, QFN 6 `debug_map`, QFN 7 `debug_trace`", "One common line can enable or disable all three together"),
])}

Only one Chip Select should normally be asserted for a transaction. Thus the Caravel control SPI uses four MCU-controlled nets in total: two shared SPI signals and two independent Chip Selects. It does not require parallel transactions on both slaves. A fifth common DEBUG net can fan out to all three debug inputs if independent debug control is unnecessary.

## Texture-PMOD implications

The dedicated ASIC's `TEX_PMOD_TYPE` is a logical selector for its supported connector wiring convention. Caravel lacks that selector, but exposes the same board-level texture signals: `tex_cs_n`, `tex_sclk` and `tex_io[3:0]`. A Caravel adapter can therefore implement the desired PMOD convention by physically routing those signals to the appropriate connector pins. This changes adapter wiring rather than the MCU or texture-memory protocol.

## Reset and startup implications

- The dedicated ASIC's `RESET_N` directly resets Raybox.
- Caravel QFN pin 21 `RESETb` is electrically compatible with the same active-low board reset, but first resets the Caravel management system. Normal Raybox reset behaviour relies on firmware establishing the intended mux/reset-propagation policy.
- QFN pin 36 `opt_user_reset / ser_rx / io[5]` is an additional Caravel-only route. It can become an active-high user-design reset only after the pad and mux are configured appropriately.
- Caravel also requires management firmware, firmware flash, GPIO transfer, mux selection and an explicit design-reset sequence before Raybox should be considered ready.

For a common board, use the active-low reset net for dedicated `RESET_N` or Caravel `RESETb`. Treat `opt_user_reset` as an optional Caravel-specific enhancement, not as the primary power-on reset.

## Caravel `gpout[2:0]` selector reference

{md_table(["Selector", "gpout[0]", "gpout[1]", "gpout[2]"], gpout)}

The dedicated ASIC exposes `HBLANK`, `VBLANK`, `HMAX`, `VMAX` and all ten `VPOS` bits simultaneously. Caravel has only three `gpout` pins, although they are more flexible. `VPOS[2:7]` are not selectable by the current Caravel mux. `gpout[2]` is always unregistered; `gpout[0]` and `gpout[1]` follow `reg_outs_enb`.

Selector 12 is especially useful because `tex_oeb0` exposes the direction state of bidirectional `tex_io0`: low means its output driver is enabled; high means input/high-impedance.

## Practical common-devkit interface

A shared baseboard should route by logical function rather than package number:

- system clock and active-low primary reset;
- RGB222, `hsync_n` and `vsync_n`;
- texture CS, SCLK and IO0-IO3;
- shared control-SPI SCLK/MOSI plus variant-specific Chip Select handling;
- generated-texture selection with polarity adaptation;
- registered-output selection with polarity adaptation;
- mode controls through variant-specific adapter logic, with DEBUG either fanned out as one common line or exposed separately on Caravel;
- diagnostics through either fixed ASIC pins or selected Caravel `gpout` sources;
- a Caravel firmware-ready indication before the controller assumes the user design is operational.

The cleanest architecture is a common logical interface with variant-specific ASIC modules or adapters. Caravel-specific management flash, housekeeping SPI, UART and firmware sequencing should remain on the Caravel module rather than complicating the dedicated-ASIC interface.

## Primary sources

- Wafer.space slot definition: <https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/librelane/slots/slot_1x0p5.yaml>
- Dedicated-ASIC pad-ring script: <https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/scripts/padring.py>
- Wafer.space COB/mezzanine schematic: <https://github.com/wafer-space/chip-on-board-wire-bonded-pcbs/blob/main/run-2/1x0p5-cob/mezzanine-1x0p5.kicad_sch>
- Caravel wrapper: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/user_project_wrapper.v>
- Caravel design mux: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/mux/top_design_mux.v>
- Raybox Caravel top: <https://github.com/algofoogle/algofoogle-multi-caravel/blob/9871f786967d514317c7a2e1e2b2107cce685c2d/verilog/rtl/raybox-zero-fsm/src/rtl/top_raybox_zero_fsm.v>
- Caravel QFN64 schematic: <https://github.com/efabless/caravel_board/blob/2812cfd3896e2b1004b5f4559e0601c90cd18f55/hardware/breakout/caravel-M.2-card-QFN/caravel-M.2-card-QFN.kicad_sch>
"""
MD.write_text(md, encoding="utf-8")


PAGE_W, PAGE_H = landscape(A4)
styles = getSampleStyleSheet()
title = ParagraphStyle("TitleX", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=18, leading=21, textColor=colors.HexColor("#10233f"), spaceAfter=5*mm)
h1 = ParagraphStyle("H1X", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=12, leading=14, textColor=colors.HexColor("#17365d"), spaceBefore=3*mm, spaceAfter=1.5*mm)
body = ParagraphStyle("BodyX", parent=styles["BodyText"], fontName="Helvetica", fontSize=8.2, leading=10.5, textColor=colors.HexColor("#1f2937"), spaceAfter=2*mm)
small = ParagraphStyle("SmallX", parent=body, fontSize=6.4, leading=7.5, spaceAfter=0)
small_c = ParagraphStyle("SmallCX", parent=small, alignment=TA_CENTER)
th = ParagraphStyle("TH", parent=small_c, fontName="Helvetica-Bold", textColor=colors.white, fontSize=6.4, leading=7.4)
note = ParagraphStyle("NoteX", parent=body, fontSize=7.2, leading=9, textColor=colors.HexColor("#475569"))


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def para(s, style=small):
    return Paragraph(esc(s), style)


def page_decor(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#cbd5e1"))
    canvas.line(9*mm, 8*mm, PAGE_W-9*mm, 8*mm)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.drawString(9*mm, 4.8*mm, "Raybox Zero dedicated ASIC vs Caravel pin comparison")
    canvas.drawRightString(PAGE_W-9*mm, 4.8*mm, f"Page {doc.page}")
    canvas.restoreState()


doc = BaseDocTemplate(str(PDF), pagesize=landscape(A4), leftMargin=8*mm, rightMargin=8*mm, topMargin=6*mm, bottomMargin=10*mm, title="Raybox Zero dedicated ASIC vs Caravel pin and interface comparison", author="OpenAI for Anton Maurovic")
frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")
doc.addPageTemplates([PageTemplate(id="landscape", frames=frame, onPage=page_decor)])

story = [
    Paragraph("Raybox Zero dedicated ASIC vs Caravel pin and interface comparison", title),
    Paragraph("Revision 2026-11-12 | wafer.space GF180 1x0.5 dedicated ASIC compared with Raybox Zero design 0 in the GFMPW1 Caravel QFN64 implementation", note),
    Paragraph("How to read the comparison", h1),
    Paragraph("<b>Same</b>: board-visible signal and normal function are effectively the same. <b>Equivalent</b>: implementation details differ, but normal user-facing operation and external hardware can remain the same. <b>Board-unified</b>: the ASIC combines functions that Caravel exposes separately, but common wiring or coordinated Chip Selects can preserve one external interface. <b>Inverted</b>: equivalent function with opposite active polarity. <b>Differing</b>: related intent but deliberate adaptation is required. <b>ASIC-only / Caravel-only</b>: no useful one-to-one package-level equivalent.", body),
    Paragraph("Power, ground, the Caravel thermal pad, physical no-connects and unused wafer.space pads are excluded. Wafer.space numbers are die-pad numbers; Caravel numbers are physical QFN64 pins. Programmable Caravel pins appear more than once where appropriate.", note),
    Paragraph("Complete functional mapping", h1),
]

header = [para(x, th) for x in ["WS pin", "Dedicated WS ASIC", "QFN pin", "Caravel RBZ", "Match", "Function", "Difference where applicable"]]
table_data = [header]
status_fill = {"Equivalent":"#dcfce7", "Board-unified":"#ccfbf1", "Same":"#dbeafe", "Inverted":"#fef3c7", "Differing":"#fce7f3", "ASIC-only":"#ede9fe", "Caravel-only":"#e2e8f0"}
for r in rows:
    table_data.append([
        para(r[0], small_c), para(r[1]), para(r[2], small_c), para(r[3]), para(r[4], small_c), para(r[5]), para(r[6])
    ])

tbl = Table(table_data, repeatRows=1, colWidths=[12*mm, 26*mm, 13*mm, 35*mm, 18*mm, 36*mm, 141*mm], hAlign="LEFT")
ts = [
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#17365d")),
    ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#94a3b8")),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("LEFTPADDING", (0,0), (-1,-1), 2.2),
    ("RIGHTPADDING", (0,0), (-1,-1), 2.2),
    ("TOPPADDING", (0,1), (-1,-1), 2.2),
    ("BOTTOMPADDING", (0,1), (-1,-1), 2.2),
]
for idx, r in enumerate(rows, start=1):
    if idx % 2 == 0:
        ts.append(("BACKGROUND", (0,idx), (-1,idx), colors.HexColor("#f8fafc")))
    ts.append(("BACKGROUND", (4,idx), (4,idx), colors.HexColor(status_fill[r[4]])))
tbl.setStyle(TableStyle(ts))
story += [tbl, Spacer(1, 3*mm)]

story += [
    Paragraph("Caravel rgb[5:0] bit order (BBGGRR)", h1),
    Paragraph("The Caravel Raybox top-level Verilog explicitly describes o_rgb[5:0] as BBGGRR: blue occupies bits 5:4, green bits 3:2 and red bits 1:0. The design mux maps that vector to IO[15:10] without reversing it.", body),
]

rgb_data = [
    [para("Caravel bit", th)] + [para(bit, th) for bit, _, _, _ in rgb_order],
    [para("Signal", small_c)] + [para(named.split(" = ")[1], small_c) for _, _, _, named in rgb_order],
]
rgb_tbl = Table(rgb_data, colWidths=[35*mm] + [27.5*mm] * 6, hAlign="LEFT")
rgb_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365d")),("BACKGROUND",(0,1),(0,1),colors.HexColor("#e2e8f0")),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#94a3b8")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3)]))
story += [rgb_tbl, Spacer(1,2*mm), Paragraph("In particular, rgb[4] is blue bit 0, while rgb[0] is red bit 0.", body)]

story += [
    Paragraph("Shared board wiring for the Caravel control and debug interfaces", h1),
    Paragraph("The dedicated ASIC has one combined SPI interface whose command words identify the requested operation or internal destination. Caravel exposes separate register and vector SPI slaves, but SCLK and MOSI can be shared. The independently controlled Chip Selects, reg_cs_n and vec_cs_n, select the receiver for each transaction. One common DEBUG line can also drive all three Caravel debug inputs when independent control is unnecessary.", body),
]

spi_data = [[para(x, th) for x in ["MCU net", "Caravel destinations", "Purpose"]]] + [
    [para("SPI SCLK"), para("QFN 3 reg_sclk and QFN 61 vec_sclk"), para("One shared clock wire")],
    [para("SPI MOSI"), para("QFN 4 reg_mosi and QFN 62 vec_mosi"), para("One shared data wire")],
    [para("Register Chip Select"), para("QFN 2 reg_cs_n"), para("Select register SPI slave")],
    [para("Vector Chip Select"), para("QFN 60 vec_cs_n"), para("Select vector SPI slave")],
    [para("DEBUG"), para("QFN 5 debug_vec, QFN 6 debug_map and QFN 7 debug_trace"), para("One common line can enable or disable all three together")],
]
spi_tbl = Table(spi_data, repeatRows=1, colWidths=[45*mm, 100*mm, 100*mm], hAlign="LEFT")
spi_tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365d")),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#94a3b8")),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
story += [spi_tbl, Spacer(1,2*mm), Paragraph("Only one Chip Select should normally be asserted per transaction. The Caravel control SPI therefore uses four MCU-controlled nets: two shared SPI signals and two independent Chip Selects. It does not require parallel transactions. A fifth common DEBUG net can fan out to all three debug inputs if independent debug control is unnecessary.", body)]

implications = Table([[
    [Paragraph("Texture-PMOD implications", h1), Paragraph("The dedicated ASIC's TEX_PMOD_TYPE is a logical selector for connector wiring. Caravel lacks that selector, but exposes the same texture CS, SCLK and IO0-IO3 signals. A Caravel adapter can implement the selected PMOD convention through physical routing, without changing the MCU or memory protocol.", body)],
    [Paragraph("Reset and startup implications", h1), Paragraph("The dedicated ASIC's RESET_N directly resets Raybox. Caravel RESETb on QFN pin 21 can use the same active-low board net, but initially resets the management system and relies on firmware-loaded reset propagation for normal Raybox behaviour. QFN pin 36 opt_user_reset is an optional active-high route available only after pad and mux configuration. Caravel also requires management firmware, GPIO transfer, mux selection and explicit design reset before it is ready.", body)],
]], colWidths=[132*mm, 132*mm], hAlign="LEFT")
implications.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(0,0),0),("RIGHTPADDING",(0,0),(0,0),5*mm),("LEFTPADDING",(1,0),(1,0),5*mm),("RIGHTPADDING",(1,0),(1,0),0),("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
story += [implications, Paragraph("Caravel gpout[2:0] selector reference", h1)]

gdata = [[para(x, th) for x in ["Selector", "gpout[0]", "gpout[1]", "gpout[2]"]]] + [[para(x, small_c) for x in row] for row in gpout]
gt = Table(gdata, repeatRows=1, colWidths=[25*mm, 55*mm, 55*mm, 55*mm], hAlign="LEFT")
gt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365d")),("GRID",(0,0),(-1,-1),0.35,colors.HexColor("#94a3b8")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#f8fafc")]),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),1.2),("BOTTOMPADDING",(0,0),(-1,-1),1.2)]))
story += [gt, Spacer(1,2*mm), Paragraph("The ASIC exposes HBLANK, VBLANK, HMAX, VMAX and all ten VPOS bits simultaneously. Caravel has only three programmable outputs; VPOS[2:7] are unavailable. gpout[2] is always unregistered, while gpout[0:1] follow reg_outs_enb. Selector 12 exposes tex_io0 direction: low means output enabled; high means input/high-impedance.", body)]

story += [
    Paragraph("Practical common-devkit interface", h1),
    Paragraph("A shared baseboard should route by logical function: system clock and active-low primary reset; RGB222 and sync; texture CS/SCLK/IO0-IO3; shared control-SPI SCLK/MOSI plus variant-specific Chip Select handling; polarity adaptation for generated-texture and registered-output selection; variant-specific mode adaptation; DEBUG either fanned out as one common line or exposed separately on Caravel; and diagnostics through fixed ASIC pins or selected Caravel gpout sources. Caravel-specific management flash, housekeeping SPI, UART and firmware sequencing are best kept on the Caravel module.", body),
    Paragraph("Primary sources", h1),
    Paragraph("Wafer.space slot definition and padring.py; wafer.space COB/mezzanine schematic; algofoogle-multi-caravel commit 9871f786 user_project_wrapper.v, top_design_mux.v and top_raybox_zero_fsm.v; Efabless caravel_board commit 2812cfd3 QFN64 schematic. Full URLs are included in the Markdown version.", note),
]

doc.build(story)
print(MD)
print(PDF)
