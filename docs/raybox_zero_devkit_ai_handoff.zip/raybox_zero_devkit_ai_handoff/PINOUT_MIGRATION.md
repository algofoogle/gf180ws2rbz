# RBZM-1 pinout migration — 19 November 2026

RBZM-1 is now official. It adopts the routing viewer's former **Alternate** pinout. The connector coordinates, pad numbers, holes, spacing, symbol library name and footprint identifier remain unchanged. The 16 November proposal is **superseded**.

**Do not directly mate old-proposal and RBZM-1 boards. R1/R15 exchange RBZ_VDD and GND, which can short the supply.** Label module/baseboard revisions and check continuity before power-up. Use an explicitly wired adapter if different revisions must interoperate.

| Physical contact | Old proposal | Official RBZM-1 |
|---|---|---|
| L5 | `INC_X` | `REG` |
| L6 | `INC_Y` | `INC_X` |
| L8 | `REG` | `INC_Y` |
| L9 | `HBLANK/GPOUT0` | `VBLANK/GPOUT1` |
| L10 | `VBLANK/GPOUT1` | `HBLANK/GPOUT0` |
| L16 | `CLK` | `RESET_N` |
| L18 | `RESET_N` | `CLK` |
| R1 | `RBZ_VDD` | `GND` |
| R3 | `CTRL_REG_CSb` | `RBZM_SPI_SCK` |
| R4 | `VEC_CSb` | `RBZM_SPI_MOSI` |
| R5 | `RBZM_SPI_MOSI` | `CTRL_REG_CSb` |
| R6 | `RBZM_SPI_SCK` | `VEC_CSb` |
| R7 | `HK_SDO` | `HK_CSb` |
| R8 | `HK_CSb` | `HK_SDO` |
| R15 | `GND` | `RBZ_VDD` |
| R23 | `VSYNC_N` | `HSYNC_N` |
| R24 | `HSYNC_N` | `VSYNC_N` |
| R25 | `SER_TX` | `SER_RX/OPT_URST` |
| R26 | `SER_RX/OPT_URST` | `SER_TX` |

All other contacts retain their assignments. RGB remains B–G–R from top to bottom in the right-bank video group; bit significance within each pair is unchanged. L14 remains the other RBZ_VDD contact.

## KiCad migration

1. Back up or commit the project and identify which pinout its cached symbol and PCB currently implement.
2. Install the updated `RBZM.kicad_sym` and `Anton.pretty/RBZM_Raybox_Zero_Module.kicad_mod`. Their library identifiers are intentionally unchanged.
3. In the schematic, run **Update Symbols from Library** for every RBZM instance. Existing placed symbols contain cached pin definitions; replacing library files alone is insufficient.
4. Inspect all 19 changed contacts. KiCad preserves existing connected wiring by geometry/pin, so existing net labels or circuit connections can now land on a different function. Rewire/relabel them deliberately. Electrical pins remain passive except L1 N/C, so ERC alone cannot validate this interface migration.
5. Run **Update PCB from Schematic** and inspect the reassigned pad nets. Updating the footprint alone cannot remap PCB nets. Existing tracks may now serve the wrong function and must be rerouted as needed, especially R1/R15 supply/ground copper.
6. Compare the final schematic and PCB against `RBZM_pinout.csv`, check mirrored bottom-side mating views, and verify supply/ground continuity before assembly or power-up.

## Control polarity

GEN_TEXb and REG have direct wiring on RBZM-Caravel, with no inline inverters. They keep the existing WS-oriented names. The CH32X033/controller uses module type to implement the requested logical function: generated textures = low on WS / high on Caravel; registered outputs = high on WS / low on Caravel. Startup pulls must match the actual receiving function.

## Archive

`archive/RBZM_proposal_2026-11-16/` contains unmodified old KiCad and documentation ZIPs, the old guide and old mapping, with a superseded warning. Historical chip-package diagrams are not the RBZM connector pinout and are unchanged.
