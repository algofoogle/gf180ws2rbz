# RBZM-1 update integrity audit

Update: 19 November 2026.

- Prior handoff files: 30.
- Prior files missing after update: **0**.
- Prior paths updated: 18.
- Added paths before this audit: 65.
- All chip/die diagrams under `diagrams/`: byte-identical.
- All 64 footprint pad definitions: unchanged; connector geometry/numbering is preserved.
- Archive KiCad ZIP, guide ZIP and Markdown: byte-identical to the materialized prior versions.
- 64 symbol names, guide table entries, neutral pin exports and physical-diagram labels validated.
- All 65 QFN positions exported; 36 direct signal positions independently checked against the adopted assignment (fan-outs produce 39 branches).
- Official/archived viewer selection, group checklist, pad hover/click and extra-curved mode passed DOM interaction checks.

## Updated existing paths

- `MANIFEST.sha256`
- `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md`
- `README.md`
- `docs/caravel_raybox_zero_hardware_integration.md`
- `docs/conversation_reconstruction.md`
- `docs/package_scope_and_omissions.md`
- `docs/raybox_zero_asic_caravel_pin_comparison.md`
- `docs/raybox_zero_asic_caravel_pin_comparison_landscape.pdf`
- `docs/raybox_zero_caravel_useful_links.md`
- `docs/rbzm/RBZM.md`
- `docs/rbzm/diagrams/footprint.svg`
- `docs/rbzm/diagrams/left.svg`
- `docs/rbzm/diagrams/physical-interface.svg`
- `docs/rbzm/diagrams/right.svg`
- `kicad/rbzm/Anton.pretty/RBZM_Raybox_Zero_Module.kicad_mod`
- `kicad/rbzm/RBZM.kicad_sym`
- `kicad/rbzm/generate_rbzm.py`
- `scripts/generate_rbz_pin_comparison.py`

## Added content

New content includes the superseded proposal archive, revision/migration notes, neutral pinout JSON/CSV, QFN mapping, diagram generator and templates, consistency validator, and complete routing-study package. Historical chronology is preserved with an appended adoption note. `MANIFEST.sha256` files were regenerated.
