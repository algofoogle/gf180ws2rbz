#!/usr/bin/env python3
"""Regenerate the official RBZM-1 release assets in place.

Requires Python 3 and kicad-cli. Edit the official generator/guide sources, not
the archived proposal. This script synchronizes the routing source with the
official pin export, then validates symbol/table/diagram agreement.
"""
from pathlib import Path
import subprocess,sys,shutil,json,csv

ROOT=Path(__file__).resolve().parent
K=ROOT/'kicad/rbzm';D=ROOT/'docs/rbzm';R=ROOT/'routing/RBZM_Caravel_routing_study'

def run(*args):subprocess.run([sys.executable,*map(str,args)],check=True)

def main():
    run(K/'generate_rbzm.py')
    run(D/'generate_rbzm_diagrams.py','--kicad-dir',K)
    shutil.copy(K/'RBZM_pinout.json',R/'inputs/RBZM_pinout.json')
    shutil.copy(K/'Anton.pretty/RBZM_Raybox_Zero_Module.kicad_mod',R/'inputs/RBZM_Raybox_Zero_Module.kicad_mod')
    run(R/'generate_study.py')
    source=json.loads((R/'inputs/mapping.json').read_text())
    records=json.loads((K/'RBZM_pinout.json').read_text())['pins'];names={p['name']:p['pin'] for p in records}
    ground=[p['pin'] for p in records if p['name']=='GND'];power=[p['pin'] for p in records if p['name']=='RBZ_VDD']
    rows=[]
    for q in range(1,66):
        pad=source['qfn'][str(q)];es=[e for e in source['edges'] if e['qfn']==q];label=pad['name']
        if es:contacts=[names[e['net']] for e in es];net=[e['net'] for e in es];note='Direct signal connection'
        elif label.startswith('vss') or q==65:contacts=ground;net=['GND'];note='Common ground; connect exposed pad 65'
        elif label.startswith(('vdd','vcc')):contacts=power;net=['RBZ_VDD'];note='Named supply domain, tied to common RBZ_VDD in this module plan'
        elif q in (24,25,26,27):contacts=[];net=[];note='Local boot-flash circuit and level adaptation; not an RBZM contact'
        elif q in (31,41):contacts=[];net=[];note='Local diagnostic/test access only; not an RBZM contact'
        else:contacts=[];net=[];note='Physical no-connect'
        if q in (8,13):note+='; polarity handled by module-type-aware controller, no inline inverter'
        rows.append(dict(Caravel_QFN_pin=q,Caravel_name=label,RBZM_contacts=';'.join(contacts),RBZM_names=';'.join(net),note=note))
    for directory in (K,D):
        with (directory/'Caravel_to_RBZM.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    run(K/'validate_rbzm.py','--docs',D)

if __name__=='__main__':main()
