# Raybox Zero devkit AI handoff package

This archive is a portable context snapshot for continuing the Raybox Zero hardware work in a new AI/LLM conversation. Start by uploading the whole ZIP if the destination supports archives; otherwise upload `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md` together with the files it names.

## Recommended reading order

1. `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md` — concise project state, constraints, known facts, open questions, and a ready-to-use prompt.
2. `docs/caravel_raybox_zero_hardware_integration.md` — detailed Caravel boot, reset, pin, firmware, `gpout`, and flash-programming analysis.
3. `docs/raybox_zero_caravel_useful_links.md` — primary sources and direct code hot spots.
4. `docs/raybox_zero_asic_caravel_pin_comparison.md` — consolidated functional pin/interface comparison, including the explicit Caravel `rgb[5:0]` bit order and common-board wiring guidance.
5. `docs/package_scope_and_omissions.md` — what is deliberately or presently absent from the archive.
6. `docs/conversation_reconstruction.md` — available request chronology and reconstructed outcomes, with provenance limitations stated at the top.
7. `diagrams/wafer_space_1x0p5_padring.svg` — latest GDS-derived dedicated-die/bond-pad diagram.
8. `diagrams/caravel_raybox_zero_qfn64.svg` — current physical QFN64 pinout diagram.
9. `kicad/caravel_raybox_zero.kicad_sym` — generated KiCad symbol library.

## Included generators

- `scripts/generate_caravel_raybox_diagram.py` regenerates the Caravel QFN64 diagram from the Efabless QFN schematic. It writes SVG directly and can optionally invoke Inkscape or `rsvg-convert` for PNG/PDF.
- `scripts/generate_padring_diagram.py` regenerates the wafer.space 1×0.5 die/bond-pad diagram from the hierarchical GDS. SVG output needs only Python; PNG/PDF export uses Inkscape.
- `scripts/generate_caravel_raybox_symbol.py` regenerates the two-symbol KiCad library.
- `scripts/generate_rbz_pin_comparison.py` regenerates both the Markdown comparison and its landscape PDF. It requires Python and ReportLab.

The package intentionally does **not** redistribute external repository files. The generators' required upstream inputs and exact source URLs are documented in the handoff and link index.

## Integrity

`MANIFEST.sha256` contains SHA-256 hashes for all package files except itself. Paths are relative to this directory.
