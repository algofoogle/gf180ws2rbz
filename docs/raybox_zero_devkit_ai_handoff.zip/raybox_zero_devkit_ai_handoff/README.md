# Raybox Zero devkit AI handoff package

This archive is a portable context snapshot for continuing the Raybox Zero hardware work in a new AI/LLM conversation. Start by uploading the whole ZIP if the destination supports archives. Otherwise upload `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md` together with the files it names and the RBZM guide below.

## Start here for RBZM work

- Use [RBZM.md](docs/rbzm/RBZM.md) for the approved connector pinout and prototype design intent. This is the official RBZM-1 guide adopted 19 November 2026, with all linked SVGs under `docs/rbzm/diagrams/`. Older discussion and comparison documents provide background. If they differ on the RBZM interface, follow the approved guide.
- Use the [KiCad symbol](kicad/rbzm/RBZM.kicad_sym), [footprint](kicad/rbzm/Anton.pretty/RBZM_Raybox_Zero_Module.kicad_mod) and [Python generator](kicad/rbzm/generate_rbzm.py) for exact connector geometry and pin assignments.
- Read [the migration notes](docs/rbzm/PINOUT_MIGRATION.md): 19 assignments changed, including the electrically incompatible R1/R15 supply/ground swap. The old proposal is under `archive/RBZM_proposal_2026-11-16/`; do not use it for new designs.
- Machine-readable assignments: [JSON](docs/rbzm/RBZM_pinout.json), [CSV](docs/rbzm/RBZM_pinout.csv), and [QFN-to-RBZM map](docs/rbzm/Caravel_to_RBZM.csv). The [routing viewer](routing/RBZM_Caravel_routing_study/output/interactive.html) defaults to the official mapping; its old-proposal option is archived comparison only.
- GEN_TEXb/REG use direct Caravel wiring; controller firmware handles module-specific polarity, with no inline inverters.
- RBZM is prototype-only. Direct GFMPW1 population is optional, whole-chip 3.3 V operation is experimental, and texture-flash takeover and buffered video output still need bench validation.
- To resume the design, start with the [PCB layout checklist](docs/rbzm/RBZM.md#pcb-layout-checklist) and [bring-up notes](docs/rbzm/RBZM.md#baseboard-integration-and-bring-up). The working-repo path and commit are pending. Record them here once this snapshot is committed.

## Recommended reading order

1. `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md` — concise project state, constraints, known facts, open questions, and a ready-to-use prompt.
2. `docs/caravel_raybox_zero_hardware_integration.md` — detailed Caravel boot, reset, pin, firmware, `gpout`, and flash-programming analysis.
3. `docs/raybox_zero_caravel_useful_links.md` — primary sources and direct code hot spots.
4. `docs/raybox_zero_asic_caravel_pin_comparison.md` — consolidated functional pin/interface comparison, including the explicit Caravel `rgb[5:0]` bit order and common-board wiring guidance.
5. `docs/package_scope_and_omissions.md` — what is deliberately or presently absent from the archive.
6. `docs/conversation_reconstruction.md` — available request chronology and reconstructed outcomes, with provenance limitations stated at the top.
7. `diagrams/wafer_space_1x0p5_padring.svg` — latest GDS-derived dedicated-die/bond-pad diagram.
8. `diagrams/caravel_raybox_zero_qfn64.svg` — current physical QFN64 pinout diagram.
9. `kicad/caravel_raybox_zero.kicad_sym` — generated KiCad symbol library.

## Included generators

Run `python3 regenerate_rbzm_assets.py` from the handoff root to synchronize the official RBZM pin-dependent outputs and run the consistency validator. This requires Python 3 and kicad-cli.


- `scripts/generate_caravel_raybox_diagram.py` regenerates the Caravel QFN64 diagram from the Efabless QFN schematic. It writes SVG directly and can optionally invoke Inkscape or `rsvg-convert` for PNG/PDF.
- `scripts/generate_padring_diagram.py` regenerates the wafer.space 1×0.5 die/bond-pad diagram from the hierarchical GDS. SVG output needs only Python; PNG/PDF export uses Inkscape.
- `scripts/generate_caravel_raybox_symbol.py` regenerates the two-symbol KiCad library.
- `scripts/generate_rbz_pin_comparison.py` regenerates both the Markdown comparison and its landscape PDF. It requires Python and ReportLab.

The routing study includes small source-footprint snapshots needed for its geometry. The package does **not** vendor complete external repositories or the GDS. The generators' required upstream inputs and exact source URLs are documented in the handoff and link index.

- `kicad/rbzm/generate_rbzm.py` regenerates the official symbol, footprint and neutral pinout exports.
- `python3 docs/rbzm/generate_rbzm_diagrams.py --kicad-dir kicad/rbzm` regenerates the assignment-dependent guide SVGs (requires kicad-cli; command shown from the handoff root).
- `routing/RBZM_Caravel_routing_study/generate_study.py` regenerates the official/archived placement studies and viewer.

## Integrity

`MANIFEST.sha256` contains SHA-256 hashes for all package files except itself. Paths are relative to this directory.
