#!/usr/bin/env python3
"""Cross-check official RBZM-1 exports; optionally compare the guide/diagrams.

python3 validate_rbzm.py --docs ../docs
No dependencies beyond Python 3. Explicit safety-critical expected contacts are
independent of the generator, and symbol/table/diagram consistency is checked.
"""
from pathlib import Path
import argparse,json,re,xml.etree.ElementTree as E,csv

BASE=Path(__file__).resolve().parent
EXPECTED={'L5':'REG','L6':'INC_X','L8':'INC_Y','L9':'VBLANK/GPOUT1','L10':'HBLANK/GPOUT0',
 'L16':'RESET_N','L18':'CLK','R3':'RBZM_SPI_SCK','R4':'RBZM_SPI_MOSI','R5':'CTRL_REG_CSb','R6':'VEC_CSb',
 'R7':'HK_CSb','R8':'HK_SDO','R23':'HSYNC_N','R24':'VSYNC_N','R25':'SER_RX/OPT_URST','R26':'SER_TX',
 'R1':'GND','R15':'RBZ_VDD','L14':'RBZ_VDD'}

def sexp(text):
    tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',text);stack=[];root=None
    for t in tokens:
        if t=='(':
            v=[]
            if stack:stack[-1].append(v)
            stack.append(v)
        elif t==')':root=stack.pop()
        else:stack[-1].append(json.loads(t) if t.startswith('"') else t)
    assert not stack
    return root

def walk(node):
    if isinstance(node,list):
        yield node
        for child in node:yield from walk(child)

def child(node,key):return next(x for x in node if isinstance(x,list) and x and x[0]==key)

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--docs',type=Path);args=a.parse_args()
    meta=json.loads((BASE/'RBZM_pinout.json').read_text());pins={p['pin']:p for p in meta['pins']}
    assert meta['revision']=='RBZM-1 (2026-11-19)' and len(pins)==64
    for pin,name in EXPECTED.items():assert pins[pin]['name']==name,(pin,name)
    forms=list(walk(sexp((BASE/'RBZM.kicad_sym').read_text())))
    entries=[n for n in forms if n and n[0]=='pin'];assert len(entries)==64
    for pin in entries:
        num=child(pin,'number')[1];assert child(pin,'name')[1]==pins[num]['name'],num
        if num=='L1':assert pin[1]=='no_connect'
    fp=list(walk(sexp((BASE/'Anton.pretty/RBZM_Raybox_Zero_Module.kicad_mod').read_text())))
    pads=[n for n in fp if n and n[0]=='pad'];assert len(pads)==64
    for pad in pads:
        rec=pins[pad[1]];at=child(pad,'at');assert abs(float(at[1])-rec['x_mm'])<1e-6 and abs(float(at[2])-rec['y_mm'])<1e-6
    csvpins={p['pin']:p for p in csv.DictReader((BASE/'RBZM_pinout.csv').open())}
    assert {p:v['name'] for p,v in csvpins.items()}=={p:v['name'] for p,v in pins.items()}
    if args.docs:
        doc=args.docs/'RBZM.md';rows={}
        for line in doc.read_text().splitlines():
            m=re.match(r'\| ([LR]\d+) \| `([^`]+)` \|',line)
            if m:assert m[1] not in rows;rows[m[1]]=m[2]
        assert rows=={p:v['name'] for p,v in pins.items()}
        elements=list(E.parse(args.docs/'diagrams/physical-interface.svg').getroot().iter())
        labels={e.get('data-pin'):e.text for e in elements if e.get('data-role')=='label'}
        assert labels==rows
        leaders={e.get('data-pin'):e for e in elements if e.get('data-role')=='leader'}
        assert 'marker-start' in leaders['R25'].attrib and 'marker-end' in leaders['R26'].attrib
        assert 'marker-start' in leaders['R7'].attrib and 'marker-end' in leaders['R8'].attrib
        assert all('marker-start' not in leaders[p].attrib and 'marker-end' not in leaders[p].attrib for p in ('R1','R15'))
    print('PASS: official contacts, 64 symbol pins, 64 footprint pads, CSV/JSON'+(', Markdown and physical diagram' if args.docs else ''))

if __name__=='__main__':main()
