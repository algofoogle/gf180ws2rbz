# Raybox Zero multi-ASIC devkit: AI handoff

**Context snapshot:** 2026-11-11  
**Purpose:** give a new ChatGPT conversation or other LLM enough verified context, source links, artifacts, and explicit uncertainties to continue hardware design without repeating the full investigation.

## How the next AI should use this package

Treat this as a curated engineering handoff, not as a substitute for checking primary sources. Preserve the distinction between:

- **Verified implementation facts:** traced to RTL, firmware, KiCad sources, or generated artifacts in this package.
- **Current design decisions:** choices made for diagrams/symbols or recommended board architecture; these can be revisited.
- **Open items:** not yet verified or dependent on the future ASIC/devkit requirements.

Before committing a schematic or PCB decision, check the pinned source revision where one is given and then compare it with the current upstream branch. Do not silently infer voltage tolerance, pin defaults, reset behavior, or simultaneous-drive safety.

### Suggested opening prompt

> Use the attached Raybox Zero devkit handoff package as the starting context. Read `RAYBOX_ZERO_DEVKIT_AI_HANDOFF.md`, then consult the detailed integration guide and source hot spots as needed. Help me design a devkit that can support (a) the wafer.space 1×0.5 COB Raybox Zero ASIC through its standard mezzanine interface, (b) the GFMPW1 Caravel QFN64 Raybox Zero, and (c) a future ASIC revision. Clearly separate verified source facts from proposals, call out voltage-domain and bus-contention hazards, and keep a decision log as the design evolves.

## Project objective

Develop a reusable board/system architecture around Raybox Zero that can accommodate:

1. The dedicated **wafer.space 1×0.5 GF180 Raybox Zero ASIC**, supplied as a chip-on-board bonded die and normally exposed through the wafer.space COB-to-mezzanine interface.
2. The **GFMPW1 Caravel-based Raybox Zero**, a 5 V Caravel QFN64 device whose management firmware selects and starts Raybox Zero as mux design 0.
3. A **future dedicated ASIC revision**, without forcing the baseboard to copy every historical pin-level quirk.

A strong starting architecture is a shared low-voltage baseboard plus replaceable ASIC-specific modules/adapters. The baseboard owns common user-facing functions; each module owns its package, supply decoupling, reset policy, level translation, and mapping to a stable internal connector. This is a proposal, not a settled design.

## The two current implementations

### Wafer.space 1×0.5 dedicated ASIC

- Floorplan definition: `DIE_AREA = [0, 0, 3932, 2531] µm` and `CORE_AREA = [442, 442, 3490, 2089] µm` in the original slot YAML. A later GDS-derived power-strap-inclusive core bounding box used for the diagram was approximately `(384.700, 385.260)–(3547.620, 2143.140) µm`; recheck against the actual GDS before physical-layout work.
- There are 72 ordered die pads: 24 south, 12 east, 24 north, and 12 west.
- Pin 1 is at the left side of the south edge; numbering proceeds around the die according to the generated pad-ring convention.
- The source-of-truth pad ordering is [`slot_1x0p5.yaml`](https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/librelane/slots/slot_1x0p5.yaml), consumed by [`padring.py`](https://github.com/algofoogle/gf180ws2-raybox-zero/blob/main/scripts/padring.py).
- The standard COB/mezzanine schematic is [`mezzanine-1x0p5.kicad_sch`](https://github.com/wafer-space/chip-on-board-wire-bonded-pcbs/blob/main/run-2/1x0p5-cob/mezzanine-1x0p5.kicad_sch); its die-pad symbol is `U102`.
- The latest diagram uses **`TEX_PMOD_TYPE=1` mode** and expanded mode names. Pad labels distinguish Raybox names from wafer.space defaults; unused digital and analogue pads use distinct hatching; pads 61/62 highlight their non-digital VDD/VSS names; and the drawing includes GDS-derived pad coordinates, corner Metal5 artwork, and the Metal4/core bounding box.
- The package includes the latest diagram as `diagrams/wafer_space_1x0p5_padring.{svg,pdf,png}` and its generator as `scripts/generate_padring_diagram.py`.
- The generator reads the hierarchical GDS directly: layer 0/0 for the die boundary, 81/10 for 60 µm × 60 µm pad-opening markers and labels, 81/0 Metal5 artwork from the `gf180mcu_ws_ip__...` corner cells, and top-level 46/0 Metal4 geometry for the core/power-strap extent. Invoke it as `python3 scripts/generate_padring_diagram.py INPUT.gds -o wafer_space_1x0p5_padring --png --pdf`.
- The GDS itself is not redistributed in this archive. Supply the original hierarchical GDS when regenerating; do not infer physical pad coordinates from the YAML alone.

### Caravel GF180 QFN64 implementation

- The traced multi-project source revision is [`9871f786`](https://github.com/algofoogle/algofoogle-multi-caravel/tree/9871f786967d514317c7a2e1e2b2107cce685c2d).
- Raybox Zero is **design 0** behind `top_design_mux`.
- Package mapping is derived from `U1` in the [Caravel QFN64 M.2-card schematic](https://github.com/efabless/caravel_board/blob/main/hardware/breakout/caravel-M.2-card-QFN/caravel-M.2-card-QFN.kicad_sch).
- The generated package diagram and KiCad symbols are included in this archive.
- The logical symbol groups are:

| Group | Caravel user IO | Function |
|---|---|---|
| Register SPI slave | `io[27:25]` | `reg_cs_n`, `reg_sclk`, `reg_mosi` |
| Vector SPI slave | `io[24:22]` | `vec_cs_n`, `vec_sclk`, `vec_mosi` |
| Texture QSPI master | `io[21:16]` | `tex_cs_n`, `tex_sclk`, `tex_io[3:0]`; `tex_io0` is bidirectional |
| VGA | `io[15:8]` | active-low HSYNC/VSYNC and six RGB bits |
| Diagnostic outputs | `io[37:35]` | `gpout[2:0]` |
| Demo controls | `io[34:32]` | `mode0_inc_px`, `mode1_inc_py`, `mode2_gen_tex` |
| Debug controls | `io[30:28]` | `debug_vec`, `debug_map`, `debug_trace` |
| Output registration | `io[31]` | `reg_outs_enb`, active low |

Management-side groups include `io[4:0]` housekeeping, `io[6:5]` serial/reset overlays, `io[7]` IRQ, dedicated firmware flash pins 24–27, the standalone `gpio` on package pin 28, `RESETb` on package pin 21, and shared `system_clk` on package pin 22.

The detailed package-pin table is in `docs/caravel_raybox_zero_hardware_integration.md`; do not derive physical pin numbers from the user-IO index.

## Caravel boot and reset facts that affect the PCB

Power, clock, and package `RESETb` alone do **not** make the Caravel part a running Raybox Zero. Management firmware must:

1. establish the management clock/divider;
2. hold or explicitly reset design 0;
3. select design 0 and load a known mux/reset policy;
4. provide the two mux configuration-clock edges required by the two-flop control path;
5. configure and transfer the user pads;
6. configure mode and `gpout` selection;
7. release/pulse the design reset only after inputs and clock are stable.

Important consequences:

- The mux control registers are not safely assumed to power up in a desired state. Firmware should re-establish policy after every management reboot.
- QFN pin 21, `RESETb`, resets/restarts Caravel management. It only resets Raybox indirectly if firmware has enabled system-reset propagation through the mux.
- QFN pin 36 is `mprj_io[5]` / management `ser_rx`. It can become an active-high reset input for all muxed designs only when both pad ownership/configuration and the mux's IO5 reset-enable policy permit it. The diagram name `opt_user_reset` intentionally signals that conditional behavior.
- `mprj_io[6:0]` have management/housekeeping roles at startup. Do not assume they are immediately ordinary user IO.
- `system_clk` on QFN pin 22 clocks both Caravel and the selected Raybox design.

See the detailed guide for the reset equation, firmware sequence, and direct code links.

## `gpout[2:0]` options

Each output has a four-bit selector. Selector values 2–15 are common to all three outputs; 0 and 1 are output-specific.

| Sel. | `gpout[0]` | `gpout[1]` | `gpout[2]` |
|---:|---|---|---|
| 0 | `hblank` | `vblank` | `rbzero_reset` |
| 1 | `hmax` | `vmax` | `clk` |
| 2 | `vinf` | `vinf` | `vinf` |
| 3 | `clk/4` | `clk/4` | `clk/4` |
| 4 | `hpos[0]` | `hpos[0]` | `hpos[0]` |
| 5 | `hpos[1]` | `hpos[1]` | `hpos[1]` |
| 6 | `hpos[8]` | `hpos[8]` | `hpos[8]` |
| 7 | `hpos[9]` | `hpos[9]` | `hpos[9]` |
| 8 | `vpos[0]` | `vpos[0]` | `vpos[0]` |
| 9 | `vpos[1]` | `vpos[1]` | `vpos[1]` |
| 10 | `vpos[8]` | `vpos[8]` | `vpos[8]` |
| 11 | `vpos[9]` | `vpos[9]` | `vpos[9]` |
| 12 | `tex_oeb0` | `tex_oeb0` | `tex_oeb0` |
| 13 | `tex_in[0]` | `tex_in[0]` | `tex_in[0]` |
| 14 | `vec_csb` | `vec_csb` | `vec_csb` |
| 15 | `reg_csb` | `reg_csb` | `reg_csb` |

Selector 12 exposes the actual active-low output-enable state for bidirectional `tex_io0`: low means the output driver is enabled; high means input/high-impedance. Prefer `gpout[2]` for direct real-time observation because it is always unregistered; `gpout[0:1]` follow `reg_outs_enb`.

## Management SPI and firmware flash

Caravel's housekeeping SPI slave uses `mprj_io[4:1]`. It can provide a pass-through path to the separate firmware SPI flash on package pins 24–27. An external MCU or FTDI interface can therefore reprogram the firmware flash through the housekeeping pins when reset/strap/protocol conditions are correct. The Efabless `caravel_hkflash.py` utility and 5 V development board demonstrate this approach.

In the examined Caravel implementation, management flash is ordinary single-bit SPI: package flash IO0 is MOSI/output and flash IO1 is MISO/input. Do **not** treat the old `mprj_io[36:37]` flash IO2/IO3 labels as supported dual/quad flash operation; they are a historical hang-over in this Caravel version.

## Voltage domains and lessons from the Efabless 5 V board

The reference **caravel-5V-dev-v6-M.2** board is useful evidence, but it is not necessarily the ideal architecture for a new devkit.

| Interface | Reference-board treatment | Design implication |
|---|---|---|
| Main Caravel rails | Several Caravel rails tied to +5 V; user rails are separately exposed | Define exactly which rails a module requires; do not indiscriminately copy ties to a future ASIC |
| Firmware SPI, Caravel → 3.3 V flash | `SN74LV1T34` translators on CS, clock, and MOSI | Use explicit down-translation if the flash is not 5 V tolerant |
| Firmware SPI, flash → Caravel | `SN74LV1T34` translating 3.3 V MISO to 5 V | Avoid relying on an unspecified 3.3 V VIH margin at a 5 V receiver |
| UART Caravel → FTDI | `SN74LVC1G125` path performs down-translation | Protect the lower-voltage receiver |
| UART FTDI → Caravel | 3.3 V buffer/drive into Caravel | Verify Caravel VIH and buffer supply/5 V tolerance rather than assuming symmetry |
| Housekeeping SPI `io[4:1]` | Direct FTDI–Caravel connection on reference board | This relies on specific FTDI input tolerance and Caravel recognition of 3.3 V highs; explicit translation may be safer in a general board |
| FTDI `PWR_EN` → 5 V switch | `SN74LV1T34` followed by PMOS high-side switch | Keep USB/control logic isolated from the 5 V load-switch gate requirements |
| Local 3.3 V | `TAR5S33` regulator from 5 V | Budget current and thermal headroom for flash, FTDI/MCU, translators, and video support |
| FTDI internal core | 1.8 V internal/domain supply is involved | Follow the selected FTDI part's current reference schematic exactly |

Other reference-board details: a 10 MHz oscillator is powered from 5 V; the board uses an `MCP1319MT-29LE-OT` reset supervisor with a 2.9 V threshold. That low threshold supplies POR delay/manual reset but is weak brownout protection for a nominal 5 V ASIC.

## Recommended reset-supervisor approach

For a new 5 V Raybox board, a practical low-cost candidate is **APX803S-46SA-7** (nominal 4.63 V threshold, active-low open-drain reset, long power-on delay, SOT-23-3). Reconfirm availability, exact suffix, threshold tolerance, timing, and temperature grade before capture.

Typical connection: supervisor VCC to +5 V, GND to ground, open-drain RESET# with about a 10 kΩ pull-up to +5 V, local 100 nF decoupling, and an optional pushbutton to ground. The same concept can drive the dedicated ASIC's `rst_n` or Caravel `RESETb`, but the Caravel still needs firmware to configure pads/mux and explicitly reset/release Raybox.

Peripheral implications:

- **TXB0104:** has no reset. Hold `OE` low with a pull-down until both rails are valid, then enable it from logic referenced to `VCCA`. Do not simply connect a 5 V-pulled reset net to `OE` when `VCCA` is lower.
- **CH32X033:** already has internal power/reset/watchdog facilities. An optional supervisor near its own rail can reset it, but its more useful role may be to sequence the ASIC, translator enables, or power-good logic through firmware.
- **MS9288C:** the examined application/pin information did not reveal a simple external reset input. Treat reset as indirect power/regulator-enable sequencing until a definitive datasheet says otherwise. It uses additional lower-voltage rails, commonly 3.3 V and 1.8 V, which need their own regulation and sequencing review.
- **QSPI flash:** give `CS#` a pull-up and proper decoupling. Software reset sequences such as `66h`/`99h` are device-dependent. A pin named `HOLD#` or `RESET#` may double as IO3 in quad mode, so it is not a universally available hardware-reset input.

## Proposed multi-ASIC devkit partition

| Baseboard responsibility | ASIC/module responsibility |
|---|---|
| USB power/input protection, common 5 V and 3.3 V generation | Package/COB footprint and local decoupling |
| CH32X033 or other control MCU, USB bridge as required | Exact ASIC rail mapping and optional local regulators |
| User controls, headers/PMOD, VGA/HDMI path | Level translation appropriate to that ASIC's IO voltage |
| Common texture flash/connector and configuration buses | Reset supervisor or reset adaptation |
| Stable module connector and mechanical mounting | Pin remapping to the stable connector |
| Detection/identity straps and module power enable | Identification resistors/EEPROM and safe default states |

Recommended module set:

1. **Wafer.space COB mezzanine adapter:** accept the standard wafer.space mezzanine pinout without modifying the bonded-die board.
2. **Caravel QFN64 module:** package the QFN64, its management flash, reset/clock, and Caravel-specific translators; optionally expose the same stable baseboard buses.
3. **Future-ASIC module:** reserve connector pins for added IO, ID, power-good, and one or more extra rails so the baseboard does not need immediate replacement.

Never parallel outputs from two installed modules without explicit isolation. If more than one module can be physically present, use load switches plus bus switches/multiplexers or ensure only one module is powered and connected. TXB-class auto-direction translators are especially poor bus arbiters and should not be used to solve contention.

## Stable logical interface worth defining

The baseboard/module connector should express functions rather than historical package pin numbers. Candidate groups:

- power: 5 V, 3.3 V, optional 1.8 V, grounds, module power-good, module power-enable;
- clock/reset: system clock, global reset, optional user-design reset, ready/status;
- video: `rgb[5:0]`, `hsync_n`, `vsync_n`;
- texture: CS, SCLK, IO0–IO3 and optionally an observed direction/OE signal;
- control: vector SPI slave, register SPI slave, modes, debug, output-register enable;
- diagnostics: `gpout[2:0]`;
- management/programming: Caravel housekeeping SPI/UART/JTAG and firmware-flash programming only on modules that need them;
- future reserve: spare differential/analogue/digital pins, keyed module ID, and revision straps.

The dedicated ASIC and Caravel implementation do not necessarily share reset polarity, startup ownership, flash topology, or IO voltage. Adapt those differences on the module side.

## Decisions still required

1. Is the target a single-module-at-a-time carrier, or should multiple ASIC modules be installed simultaneously?
2. Must the standard wafer.space mezzanine connector be accepted directly, or may there be a thin adapter?
3. What are the verified voltage limits and current requirements for every dedicated-ASIC pad/rail and for the future revision?
4. Is the display output native VGA only, VGA plus optional MS9288C HDMI conversion, or a different digital video path?
5. Should CH32X033 replace most FTDI functions, coexist with FTDI, or leave a header for an external programmer?
6. Should the baseboard program Caravel firmware flash through housekeeping SPI, through a direct flash header/mux, or both?
7. Which texture-QSPI ownership cases must be supported, and how will `tex_io0` bidirectionality be level-shifted safely?
8. What common connector and pin budget allow a future ASIC revision without sacrificing signal integrity or power integrity?
9. What ESD, series termination, pull defaults, test points, and factory-test access are required?
10. Can the dedicated-die GDS and final COB/mezzanine netlist be added to the next handoff so its full pin map is machine-verifiable?

## Source hierarchy and package contents

For Caravel behavior, prefer RTL and firmware over diagram labels. For package numbers, prefer the pinned KiCad `U1` symbol and cross-check the package datasheet. For the dedicated die, prefer GDS marker geometry plus the slot YAML and `U102` schematic symbol.

Files included:

- `docs/caravel_raybox_zero_hardware_integration.md` — deeper source-backed analysis.
- `docs/raybox_zero_caravel_useful_links.md` — URLs, KiCanvas links, and direct line hot spots.
- `docs/raybox_zero_asic_caravel_pin_comparison.md` — consolidated dedicated-ASIC/Caravel functional pin mapping, shared-board wiring, `gpout` selections, and an explicit `rgb[5:0] = BBGGRR` reference.
- `docs/raybox_zero_asic_caravel_pin_comparison_landscape.pdf` — landscape-rendered review copy of the same comparison.
- `docs/package_scope_and_omissions.md` — explicit boundary between included artifacts, external inputs, and work not yet created.
- `docs/conversation_reconstruction.md` — chronological record of the available conversation context; older assistant turns are reconstructed rather than misrepresented as verbatim.
- `kicad/caravel_raybox_zero.kicad_sym` — logical/block and package-oriented KiCad symbols.
- `scripts/generate_caravel_raybox_symbol.py` — symbol generator.
- `scripts/generate_caravel_raybox_diagram.py` — package diagram generator; requires the upstream Caravel M.2 schematic as input.
- `scripts/generate_padring_diagram.py` — dedicated-die/bond-pad generator; requires the original hierarchical GDS as input.
- `scripts/generate_rbz_pin_comparison.py` — generates the comparison Markdown and landscape PDF; requires ReportLab.
- `diagrams/caravel_raybox_zero_qfn64.{svg,pdf,png}` — current generated physical pinout.
- `diagrams/wafer_space_1x0p5_padring.{svg,pdf,png}` — current GDS-derived dedicated-die/bond-pad diagram.

## Known limitations of this handoff

- The attached files capture the latest generated artifacts from this conversation, but no external repository is vendored or frozen in the ZIP.
- This is not a platform-exported verbatim transcript. See `docs/conversation_reconstruction.md` for the available chronology and its provenance statement.
- The original hierarchical GDS is not redistributed, but its latest generated diagram and generator are included. Reproduction still requires the original GDS because it supplies pad markers, labels, corner-cell artwork, and top-level core geometry.
- The reset-supervisor and level-shifter discussion is a design recommendation, not a completed worst-case tolerance/timing analysis.
- MS9288C documentation was limited; verify a legitimate current datasheet and reference design before committing power, reset, or video circuitry.
- Availability and prices are time-dependent and must be rechecked.
